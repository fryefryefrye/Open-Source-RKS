#ifndef ARI200_MODULE_ERRORS
#define ARI200_MODULE_ERRORS

#define COMMUNITE_ERROR       -1 
#define NO_SIM_CARD_ERROR     -2
#define SIM_CARD_NO_REG_ERROR -3
#define CALL_ERROR			  -4
//#define 
//#define 
//#define 
//#define 
//#define 
//#define 
//#define 
//#define 
//#define 
//#define

#endif